<?php
$hostname  = "http://localhost:3000/simple-blog-page-master/admin";
$conn = mysqli_connect("localhost","root","","news-site") or die("Connection failed : ".mysqli_connect_error());
?>
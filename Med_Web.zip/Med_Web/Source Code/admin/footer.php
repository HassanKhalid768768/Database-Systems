<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2023 Medicine | Powered by TeamMed <a href="">Home</a></span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
